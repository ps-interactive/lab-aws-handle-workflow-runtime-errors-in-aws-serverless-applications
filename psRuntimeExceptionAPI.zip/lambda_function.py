import json
class ResourceNotReadyException(Exception): pass
class TooManyRequestsException(Exception): pass
class ServiceException(Exception): pass
class UnknownException(Exception): pass

def lambda_handler(event, context):
    # TODO implement
    statuscode = event["statuscode"]    
    if statuscode == "502": 
        raise ResourceNotReadyException('HTTP Status Code : 502 - The function is inactive and its VPC connection is no longer available. Wait for the VPC connection to reestablish and try again.') 
    elif statuscode == "500": 
        raise ServiceException('HTTP Status Code : 500 - The AWS Lambda service encountered an internal error.') 
    elif statuscode == "429": 
        raise TooManyRequestsException('HTTP Status Code : 429 - The request throughput limit was exceeded.')
    elif statuscode == "200":
        return 'HTTP Status Code : 200 - OK'
    else:
        raise UnknownException('HTTP Status Code : ' + statuscode + ' - Unknown error')